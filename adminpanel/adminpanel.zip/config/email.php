<?php  
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.zoho.com';
$config['smtp_port'] = '465';
$config['smtp_user'] = 'do-not-reply@cherryhire.com';
$config['smtp_pass'] = 'Chire@DNply';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";
$config['mailtype'] = 'html';
/* End of file email.php */
/* Location: ./application/config/email.php */
