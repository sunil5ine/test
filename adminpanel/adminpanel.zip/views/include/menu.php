 <div class="col l3 m12 s12">
   <div class="side-bar white z-depth-1">
      <ul class="li-list ">
         <a href="recruiter-dashboard.html"><li class="active"><i class="fab fa-delicious li-icon"></i>Dashboard</li></a>
         <a href=""><li><i class="far fa-user li-icon"></i>My Account</li></a>
         <a href="manage-employers-view-active-list.html"><li><i class="fas fa-briefcase li-icon"></i>Manage Employees</li></a>
         <a href="candidate-name.html"><li><i class="fas fa-search-plus li-icon"></i>People Search</li></a>
         <a href=""><li><i class="fab fa-black-tie li-icon"></i>Manage Jobs</li></a>
         <a href=""><li><i class="fas fa-hand-holding-usd li-icon"></i>Manage Price</li></a>
         <a href="cv-writing.html"><li><i class="fas fa-file-signature li-icon"></i>Cv Writing</li></a>
         <a href="psychometric-test.html"><li><i class="fas fa-file-alt li-icon"></i>Psychometric Test</li></a>
      </ul>
   </div>
</div>